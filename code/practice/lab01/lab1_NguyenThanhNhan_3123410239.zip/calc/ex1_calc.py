'''
==== Nội dung bài ====
Nhập vào 2 số a và b, tính c là tổng của 2 số này.
'''

print("Calculator Basic")
a = int(input("Moi ban nhap so a: "))
b = int(input("Moi ban nhap so b: "))
c = a + b
print("c = %d + %d = %d" % (a, b, c))